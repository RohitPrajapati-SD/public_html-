<?php
function packages_local_seo() {
echo '
<div class="ft_pakcge-div">
<div class="ft-1st-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead border-0 bg-transparent"></div>
    <div class="th has-icon">
            <p>Price</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p>ANALYSIS & DELVERABLES</p>
    </div>
    <div class="th has-icon">
            <p>Web Analysis</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Competition Ananlysis</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Content Duplicacy Check</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Keywords Finalize</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Search Engine Optimization Strategy</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Initial Ranking report</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p>ON PAGE OPTIMIZATION</p>
    </div>
    <div class="th has-icon">
            <p>Website Structure Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Canonicalization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Content Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Image Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>HTML Code Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>HTML Site Map Creation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google XML Site Map Creation & Regular Updation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google Analytics Set up</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Robots .txt optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>RSS Feed generation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Page speed Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google Mobile Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p>OFF PAGE ACTIVITEIS (MONTHLY BASED)</p>
    </div>
    <div class="th has-icon">
            <p>Manual Search Engine Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Manual Relevant directory Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Local/ Niche Directory submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Link Exchange (One Way + Reciprocal)</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p>SOCIAL MEDIA OPTIMIZATION</p>
    </div>
    <div class="th has-icon">
            <p>Social Bookmarking and Community Advertising</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Social Networking Profile</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Article Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Article Submission (Per Article)</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Article).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Press Release Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Press Release Distribution</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Press Release).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Blog Creation, Updation & Promotion</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Forum Posting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Classified ad Creation & Posting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>RSS Feeds Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Video Promotion</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(To be provided by client).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p>REPORT STATUS</p>
    </div>
    <div class="th has-icon">
            <p>Search Engine Ranking Reports</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Monthly Work Status report (Detailed)</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Client Support</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Traffic Status report</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
</div>


<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Economy</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>100<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>7</p></div>
    <div class="td"><p>5</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>40</p></div>
    <div class="td"><p>0</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>Email</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>


<div class="star-clmn">
    <div class="thead bg-purple star white star-banner"><p>Most Popular</p></div>
    <div class="thead bg-tealblue"><p>Silver</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>125<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>7</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>40</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>50</p></div>
    <div class="td"><p>0</p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>Email</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Gold</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>175<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>10</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>50</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>60</p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>40</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Email/Chat</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Platinum</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>300<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p>15</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>60</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>4</p></div>
    <div class="td"><p>70</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>50</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p>4</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Email/Chat</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

</div>' ;

} //End packages_local_seo()



//tab-fro seo company page

function ft_tab_what_seo_can() {
		echo '
		<div class="ft_tab-seo-ind">
<ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="ft_businessReputation-tab" data-toggle="pill" href="#ft_businessReputation" role="tab" aria-controls="pills-home" aria-selected="true">Improved Business Reputation</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="ft_increasedSales-tab" data-toggle="pill" href="#ft_increasedSales" role="tab" aria-controls="pills-contact" aria-selected="false">Increased Sales</a>
  </li>
   <li class="nav-item">
    <a class="nav-link" id="ft_brandVisibility-tab" data-toggle="pill" href="#ft_brandVisibility" role="tab" aria-controls="pills-profile" aria-selected="false">Brand Visibility</a>
  </li>
</ul>
<div class="tab-content" id="pills-tabContent">
  <div class="tab-pane fade show active" id="ft_businessReputation" role="tabpanel" aria-labelledby="ft_businessReputation-tab"><p>Improves Business Reputation: If your business is not online and you are not found on relevant keywords, your potential customers might think that you are not qualified to deal with them. Everyone wants to deal with the reputed business. So your business will be judged by your presence on organic searches. SEO helps in improving your business reputation and helps you in getting more profits.</p>
  </div>

  <div class="tab-pane fade" id="ft_increasedSales" role="tabpanel" aria-labelledby="ft_increasedSales-tab">
  	<p>Increased Sales: SEO Services are very useful in increasing sales. If you are ranking on top of the search, more and more traffic will find you on Google. It increases in growth in the number of leads per day and you can easily convert more deals. So SEO Services are very useful in generating and increasing sales.</p>
  </div>

  <div class="tab-pane fade" id="ft_brandVisibility" role="tabpanel" aria-labelledby="ft_brandVisibility-tab">
  	<p>Optimizing your website on your business keywords makes you more discoverable for potential clients. Your brand is your competitive advantage, SEO Services will help you in boosting your brand visibility and loyalty to many folds.</p>
  </div>

</div>
</div>
' ;
	} //End ft_tab_what_seo_can()


// packages for national seo

function packages_national_seo() {
echo '<div class="ft_pakcge-div">
<div class="ft-1st-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead border-0 bg-transparent"></div>
    <div class="th has-icon">
            <p>Price</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p>ANALYSIS & DELVERABLES</p>
    </div>
    <div class="th has-icon">
            <p>Web Analysis</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Competition Ananlysis</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Content Duplicacy Check</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Keywords Finalize</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Search Engine Optimization Strategy</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Initial Ranking report</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p>ON PAGE OPTIMIZATION</p>
    </div>
    <div class="th has-icon">
            <p>Website Structure Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Canonicalization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Content Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Image Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>HTML Code Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>HTML Site Map Creation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google XML Site Map Creation & Regular Updation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google Analytics Set up</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Robots .txt optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>RSS Feed generation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Page speed Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google Mobile Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p>OFF PAGE ACTIVITEIS (MONTHLY BASED)</p>
    </div>
    <div class="th has-icon">
            <p>Manual Search Engine Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Manual Relevant directory Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Local/ Niche Directory submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p>SOCIAL MEDIA OPTIMIZATION</p>
    </div>
    <div class="th has-icon">
            <p>Social Bookmarking and Community Advertising</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Social Networking Profile</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Article Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Article Submission (Per Article)</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Article).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Press Release Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Press Release Distribution</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Press Release).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Blog Creation, Updation & Promotion</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Forum Posting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Classified ad Creation & Posting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Business Listing</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Question and Answer</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>PPT/PDF Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>

    <div class="th has-icon">
            <p>RSS Feeds Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Image/Infographic</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Commenting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for more details.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Video Promotion</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(To be provided by client).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p>REPORT STATUS</p>
    </div>
    <div class="th has-icon">
            <p>Search Engine Ranking Reports</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Monthly Work Status report (Detailed)</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Client Support</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Traffic Status report</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
</div>


<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Economy</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>270<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p>7</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>25</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>Email</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>


<div class="star-clmn">
    <div class="thead bg-purple star white star-banner"><p>Most Popular</p></div>
    <div class="thead bg-tealblue"><p>Silver</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>340<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p>10</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>25</p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>Email</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Gold</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>470<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>17</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>50</p></div>
    <div class="td"><p>15</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>40</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>7</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Email/Chat</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Platinum</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>790<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>25</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>60</p></div>
    <div class="td"><p>20</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>50</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>4</p></div>
    <div class="td"><p>35</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>40</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>12</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p>12</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Email/Call</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

</div>' ; }// End packages_national_seo


// packages_city_seo

function packages_city_seo() { 
    echo '<div class="ft_pakcge-div">
<div class="ft-1st-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead border-0 bg-transparent"></div>
    <div class="th has-icon">
            <p>Price</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Web Analysis</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Competition Ananlysis</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Content Duplicacy Check</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Keywords Finalize</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Search Engine Optimization Strategy</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Initial Ranking report</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Website Structure Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Canonicalization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Content Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Image Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>HTML Code Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>HTML Site Map Creation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google XML Site Map Creation & Regular Updation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google Analytics Set up</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Robots .txt optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>RSS Feed generation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Page speed Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google Mobile Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Manual Search Engine Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Manual Relevant directory Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Local/ Niche Directory submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Link Exchange (One Way + Reciprocal)</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Social Bookmarking and Community Advertising</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Social Networking Profile</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Article Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Article Submission (Per Article)</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Article).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Press Release Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Press Release Distribution</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Press Release).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Blog Creation, Updation & Promotion</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Forum Posting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Classified ad Creation & Posting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Business Listing</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Question and Answer</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>PPT/PDF Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>

    <div class="th has-icon">
            <p>RSS Feeds Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Image/Infographic</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Commenting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for more details.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Video Promotion</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(To be provided by client).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Search Engine Ranking Reports</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Monthly Work Status report (Detailed)</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Client Support</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Traffic Status report</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
</div>


<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Economy</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>160<span class="small">/month</span></span></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>7</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>Email</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>


<div class="star-clmn">
    <div class="thead bg-purple star white star-banner"><p>Most Popular</p></div>
    <div class="thead bg-tealblue"><p>Silver</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>200<span class="small">/month</span></span></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>25</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>Email</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Gold</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>280<span class="small">/month</span></span></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>17</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>40</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>7</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p>4</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Email/Chat</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Platinum</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>480<span class="small">/month</span></span></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>25</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>50</p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>50</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>4</p></div>
    <div class="td"><p>35</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>40</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>12</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>6</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Email/Chat</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

</div>' ;
} // END packages_city_seo



//packages_eccomerce_seo

function packages_eccomerce_seo() {
    echo '<div class="ft_pakcge-div">
<div class="ft-1st-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead border-0 bg-transparent"></div>
    <div class="th has-icon">
            <p>Price</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">ANALYSIS & DELIVERABLES</p>
    </div>
    <div class="th has-icon">
            <p>Web Analysis</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Competition Ananlysis</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Content Duplicacy Check</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Keywords Finalize</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Top ten Ranking for Keywords</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Search Engine Optimization Strategy</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Initial Ranking report</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">ON PAGE OPTIMIZATION</p>
    </div>
    <div class="th has-icon">
            <p>Website Structure Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Canonicalization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Content Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Image Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>HTML Code Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>HTML Site Map Creation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google XML Site Map Creation & Regular Updation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google Analytics Set up</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Robots .txt optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>RSS Feed generation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Page speed Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google Mobile Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">OFF PAGE ACTIVITIES</p>
    </div>
    <div class="th has-icon">
            <p>Manual Search Engine Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Manual Relevant directory Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Local/ Niche Directory submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Link Exchange (One Way + Reciprocal)</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">SOCIAL MEDIA OPTIMIZATION</p>
    </div>
    <div class="th has-icon">
            <p>Social Bookmarking and Community Advertising</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Social Networking Profile</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Article Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Article Submission (Per Article)</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Article).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Press Release Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Press Release Distribution</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Press Release).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Blog Creation, Updation & Promotion</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Forum Posting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Classified ad Creation & Posting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Questuion & Answer</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>PPT/PDF Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>

    <div class="th has-icon">
            <p>RSS Feeds Submission</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Image/Infographic</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Commenting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for more details.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Video Promotion</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(To be provided by client).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">REPORT STATUS</p>
    </div>
    <div class="th has-icon">
            <p>Search Engine Ranking Reports</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Monthly Work Status report (Detailed)</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Client Support</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Traffic Status report</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
</div>


<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Economy</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>270<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>25</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p>7</p></div>
    <div class="td"><p>5</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>25</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>Email</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>


<div class="star-clmn">
    <div class="thead bg-purple star white star-banner"><p>Most Popular</p></div>
    <div class="thead bg-tealblue"><p>Silver</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>340<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>50</p></div>
    <div class="td"><p>25</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>7</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>25</p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>Email</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Gold</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>470<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>100</p></div>
    <div class="td"><p>50</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>35</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>10</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>40</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p>7</p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Email/Chat</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Platinum</p></div>
    <div class="td"><p><span class="ft_price"><sup>$</sup>790<span class="small">/month</span></span></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>200</p></div>
    <div class="td"><p>100</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>40</p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p>15</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p>50</p></div>
    <div class="td"><p>15</p></div>
    <div class="td"><p>4</p></div>
    <div class="td"><p>35</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>40</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>12</p></div>
    <div class="td"><p>30</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p>12</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Email/Chat</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

</div>';
}//END packages_eccomerce_seo


//packages_web_development

function packages_web_development() {
    echo'<div class="ft_pakcge-div">
<div class="ft-1st-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead border-0 bg-transparent"></div>
    <div class="th has-icon">
            <p>Price</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Number of Pages</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Logo Design</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Breadcrumbs</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Sample Home Page Layouts</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Header Slideshow</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>W3C Valid code</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Custom Banner for Inner Pages</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Favicon</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Mobile Responsive</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Contact Us Form</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">DYNAMIC MODULES</p>
    </div>
    <div class="th has-icon">
            <p>Photo Gallery</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Video Gallery</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Testimonials/Reviews</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Product Gallery</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>News & Events</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>PDF Downloads</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Newsletter Subscriptions</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Careers</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>CMS</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">TESTING</p>
    </div>
    <div class="th has-icon">
            <p>Prelaunch Testing</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>W3C Validation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">OPTIMIZATION</p>
    </div>
    <div class="th has-icon">
            <p>HTML Sitemap</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>XML Sitemap</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Meta Tags </p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Google analytics Integration</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>On Page Optimization</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Social Media Buttons Integration</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Article).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Social Media Page Creations</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Live Chat</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Press Release).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">DOMAIN & HOSTING</p>
    </div>
    <div class="th has-icon">
            <p>1 Domain for 1 Year</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Hosting 1 year</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">UPDATE & MAINTENANCE</p>
    </div>
    <div class="th has-icon">
            <p>1 Year Technical Support</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Maintenance</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
</div>


<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Economy</p></div>
    <div class="td"><p><span class="ft_price"><sup>Rs.</sup>15000<span class="small"></span></span></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>Static</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>


<div class="star-clmn">
    <div class="thead bg-purple star white star-banner"><p>Most Popular</p></div>
    <div class="thead bg-tealblue"><p>Silver</p></div>
    <div class="td"><p><span class="ft_price"><sup>Rs.</sup>30000<span class="small"></span></span></p></div>
    <div class="td"><p>14</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>-</i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>CMS</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Gold</p></div>
    <div class="td"><p><span class="ft_price"><sup>Rs.</sup>45000<span class="small"></span></span></p></div>
    <div class="td"><p>15-20</p></div>
    <div class="td"><p>2 Samples</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>-</i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>CMS</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Platinum</p></div>
    <div class="td"><p><span class="ft_price"><sup>Rs.</sup>75000<span class="small"></span></span></p></div>
    <div class="td"><p>25+</p></div>
    <div class="td"><p>3 Samples</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>CMS</p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td bg-blue"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

</div>'; } //packages_web_development


//packeges_SMO

function packeges_SMO() {
    echo '<div class="ft_pakcge-div">
<div class="ft-1st-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead border-0 bg-transparent"></div>
    <div class="th has-icon">
            <p>Price</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
	<div class="th bg-blue">
            <p class="ft_b">FACEBOOK</p>
    </div>
    <div class="th has-icon">
            <p>Facebook Account Creation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Facebook – Timeline Status Posting</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Facebook Fan Page Creation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Facebook Profile Optimization</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Post Sharing in Groups</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Theme Related Cover Photo</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Facebook Groups Creation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Facebook Group Join</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Video Sharing</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>(Provided by Client).
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Call to Action</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Facebook Review Posting</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Deleteting unwanted spam</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Facebook Event Creation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Sponsored Ads</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Page Likes</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">TWITTER</p>
    </div>
    <div class="th has-icon">
            <p>Twitter Account Creation</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Tweets</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Retweets</p>
            <span class="icon-anchor">
           	<div class="icon-cont">
            	<p>Contact us for volume discounts or see our Agency and Partner plans.
            	    <a href="#" class="auto-track" target="_blanks">Learn More</a>
            	</p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>#Hatshtag Trend Research</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Cover Photo Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Sponsored Tweets</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Twitter List</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">LINKEDIN</p>
    </div>
    <div class="th has-icon">
            <p>Linkedin Account Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Profile Optimization</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Posting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Theme Related Cover Photo</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Article).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Targetted Linkedin Connection</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Company page Creative Banner</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Per Press Release).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Company Page Followers Increase</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Relevant Group Joining/Sharing</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Linkedin Pulse Posting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">PINTEREST</p>
    </div>
    <div class="th has-icon">
            <p>Pinterest a/c Set-up</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Profile Optimization</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Board Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Pin</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Website Verification</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th bg-blue">
            <p class="ft_b">YOUTUBE</p>
    </div>
    <div class="th has-icon">
            <p>YouTube Channel Creation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Channel Optimization</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>Contact us for volume discounts or see our Agency and Partner plans.
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Video upload</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Provided by Client).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Video Submissions</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Provided by Client).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Video Sharing in social media</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Provided by Client).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Video Subscribers</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Provided by Client).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Youtube Discussion Posting</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Provided by Client).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Youtube Video Views</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Provided by Client).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
    <div class="th has-icon">
            <p>Comment Moderation</p>
            <span class="icon-anchor">
            <div class="icon-cont">
                <p>(Provided by Client).
                    <a href="#" class="auto-track" target="_blanks">Learn More</a>
                </p>
            </div>
            </span>
    </div>
</div>


<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Economy</p></div>
    <div class="td"><p><span class="ft_price"><sup>Rs.</sup>5999<span class="small">/month</span></span></p></div>
    <div class="td"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>4</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>4</p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>One Time</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p>Additional</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p></p></div>								<!-----blank col Twitter----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>4</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Additional</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p></p></div>								<!-----blank col Linkedin----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>4</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>1</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p></p></div>								<!-----blank col Pinterest----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>4</p></div>
    <div class="td"><p><i class="icon no"></i></p></div>
    <div class="td"><p></p></div>								<!-----blank col Youtube----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="star-clmn">
    <div class="thead bg-purple star white star-banner"><p>Most Popular</p></div>
    <div class="thead bg-tealblue"><p>Silver</p></div>
    <div class="td"><p><span class="ft_price"><sup>Rs.</sup>9999<span class="small">/month</span></span></p></div>
    <div class="td"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>One Time</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Additional</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p></p></div>								<!-----blank col Twitter----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Additional</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p></p></div>								<!-----blank col Linkedin----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p></p></div>								<!-----blank col Pinterest----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>8</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p></p></div>								<!-----blank col Youtube----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>20</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

<div class="normal-clmn">
    <div class="thead border-0 bg-transparent"></div>
    <div class="thead"><p>Gold</p></div>
    <div class="td"><p><span class="ft_price"><sup>Rs.</sup>14999<span class="small">/month</span></span></p></div>
    <div class="td"><p></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>16</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>16</p></div>
    <div class="td"><p>2</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p>5</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>One Time</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Additional</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p></p></div>								<!-----blank col Twitter----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>16</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>Additional</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p></p></div>								<!-----blank col Linkedin----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>16</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>3</p></div>
    <div class="td"><p></p></div>								<!-----blank col Pinterest----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>10</p></div>
    <div class="td"><p>16</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p></p></div>								<!-----blank col Youtube----->
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p>50</p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="td"><p><i class="icon yes"></i></p></div>
    <div class="button-clmn"><a href="/contact-us"><span>Order Now</span></a></div>
</div>

</div>' ;
} // END packeges_SMO
?>