<div class="ft_pakcge-div">
    <div class="ft-1st-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead border-0 bg-transparent"></div>
        <div class="th has-icon">
                <p>Number of Pages</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Logo Design</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Breadcrumbs</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Sample Home Page Layouts</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Header Slideshow</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>W3C Valid code</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Custom Banner for Inner Pages</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Favicon</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Mobile Responsive</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Contact Us Form</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th bg-blue">
                <p class="ft_b">DYNAMIC MODULES</p>
        </div>
        <div class="th has-icon">
                <p>Photo Gallery</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Video Gallery</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Testimonials/Reviews</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Product Gallery</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>News & Events</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>PDF Downloads</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Newsletter Subscriptions</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Careers</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>CMS</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th bg-blue">
                <p class="ft_b">TESTING</p>
        </div>
        <div class="th has-icon">
                <p>Prelaunch Testing</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>W3C Validation</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th bg-blue">
                <p class="ft_b">OPTIMIZATION</p>
        </div>
        <div class="th has-icon">
                <p>HTML Sitemap</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>XML Sitemap</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Meta Tags </p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Google analytics Integration</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>On Page Optimization</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Social Media Buttons Integration</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Per Article).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Social Media Page Creations</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Live Chat</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Per Press Release).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th bg-blue">
                <p class="ft_b">DOMAIN & HOSTING</p>
        </div>
        <div class="th has-icon">
                <p>1 Domain for 1 Year</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Hosting 1 year</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th bg-blue">
                <p class="ft_b">UPDATE & MAINTENANCE</p>
        </div>
        <div class="th has-icon">
                <p>1 Year Technical Support</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Maintenance</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon bg-blue">
                <p>Price (INR)</p>
                <span class="icon-anchor">
                    <div class="icon-cont">
                        <p>Contact us for volume discounts or see our Agency and Partner plans.
                            <a href="#" class="auto-track" target="_blanks">Learn More</a>
                        </p>
                    </div>
                </span>
        </div>
        <div class="th has-icon bg-blue">
                <p>Price (USD)</p>
                <span class="icon-anchor">
                    <div class="icon-cont">
                        <p>Contact us for volume discounts or see our Agency and Partner plans.
                            <a href="#" class="auto-track" target="_blanks">Learn More</a>
                        </p>
                    </div>
                </span>
        </div>
    </div>
    
    
    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead"><p>Economy</p></div>
        <div class="td"><p>5</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>Static</p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td bg-blue"><p>INR 15,000</p></div>
        <div class="td bg-blue"><p>USD 200</p></div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft1">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft1">
            <div class="ft-content">
            <div class="ft-header"><span>Web Development - Economy package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="Web Development - Economy package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
    
    
    <div class="star-clmn">
        <div class="thead bg-purple star white star-banner"><p>Most Popular</p></div>
        <div class="thead bg-tealblue"><p>Silver</p></div>
        <div class="td"><p>14</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>2</p></div>
        <div class="td"><p>-</i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>CMS</p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td bg-blue"><p>INR 30,000</p></div>
        <div class="td bg-blue"><p>USD 400</p></div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft2">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft2">
            <div class="ft-content">
            <div class="ft-header"><span>Web Development - Silver package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="Web Development - Silver package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
    
    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead"><p>Gold</p></div>
        <div class="td"><p>15-20</p></div>
        <div class="td"><p>2 Samples</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>2</p></div>
        <div class="td"><p>-</i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>CMS</p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td bg-blue"><p>INR 45,000</p></div>
        <div class="td bg-blue"><p>USD 650</p></div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft3">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft3">
            <div class="ft-content">
            <div class="ft-header"><span>Web Development - Gold package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="Web Development - Gold package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
    
    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead"><p>Platinum</p></div>
        <div class="td"><p>25+</p></div>
        <div class="td"><p>3 Samples</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>3</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>CMS</p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p>INR 75,000</p></div>
        <div class="td bg-blue"><p>USD 1100</p></div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft4">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft4">
            <div class="ft-content">
            <div class="ft-header"><span>Web Development - Platinum package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="Web Development - Platinum package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
    
    </div>

    <div class="ft_gst">
    <p>*GST Applicable On All Plans</p>
    </div>