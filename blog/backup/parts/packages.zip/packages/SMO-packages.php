<div class="ft_pakcge-div">
    <div class="ft-1st-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead border-0 bg-transparent"></div>
        <div class="th bg-blue">
                <p class="ft_b">FACEBOOK</p>
        </div>
        <div class="th has-icon">
                <p>Facebook Account Creation</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Facebook – Timeline Status Posting</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Facebook Fan Page Creation</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Facebook Profile Optimization</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Post Sharing in Groups</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Theme Related Cover Photo</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Facebook Groups Creation</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Facebook Group Join</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Video Sharing</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Provided by Client).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Call to Action</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Facebook Review Posting</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Deleteting unwanted spam</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Facebook Event Creation</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Sponsored Ads</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Page Likes</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th bg-blue">
                <p class="ft_b">TWITTER</p>
        </div>
        <div class="th has-icon">
                <p>Twitter Account Creation</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Tweets</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Retweets</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>#Hatshtag Trend Research</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Cover Photo Creation</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Sponsored Tweets</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Twitter List</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th bg-blue">
                <p class="ft_b">LINKEDIN</p>
        </div>
        <div class="th has-icon">
                <p>Linkedin Account Creation</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Profile Optimization</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Posting</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Theme Related Cover Photo</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Per Article).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Targetted Linkedin Connection</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Company page Creative Banner</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Per Press Release).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Company Page Followers Increase</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Relevant Group Joining/Sharing</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Linkedin Pulse Posting</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th bg-blue">
                <p class="ft_b">PINTEREST</p>
        </div>
        <div class="th has-icon">
                <p>Pinterest a/c Set-up</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Profile Optimization</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Board Creation</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Pin</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Website Verification</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th bg-blue">
                <p class="ft_b">YOUTUBE</p>
        </div>
        <div class="th has-icon">
                <p>YouTube Channel Creation</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Channel Optimization</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Video upload</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Provided by Client).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Video Submissions</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Provided by Client).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Video Sharing in social media</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Provided by Client).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Video Subscribers</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Provided by Client).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Youtube Discussion Posting</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Provided by Client).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Youtube Video Views</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Provided by Client).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Comment Moderation</p>
                <span class=" ">
                <div class="icon-cont">
                    <p>(Provided by Client).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon bg-blue">
                <p>Price (INR)</p>
                <span class="icon-anchor">
                    <div class="icon-cont">
                        <p>Contact us for volume discounts or see our Agency and Partner plans.
                            <a href="#" class="auto-track" target="_blanks">Learn More</a>
                        </p>
                    </div>
                </span>
        </div>
        <div class="th has-icon bg-blue">
                <p>Price (USD)</p>
                <span class="icon-anchor">
                    <div class="icon-cont">
                        <p>Contact us for volume discounts or see our Agency and Partner plans.
                            <a href="#" class="auto-track" target="_blanks">Learn More</a>
                        </p>
                    </div>
                </span>
        </div>
    </div>
    
    
    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead"><p>Economy</p></div>
        <div class="td bg-blue"><p></p></div>                                       <!-----blank col facebook----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>4</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>4</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>One Time</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>Additional</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Twitter----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>4</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>Additional</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Linkedin----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>4</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Pinterest----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>3</p></div>
        <div class="td"><p>4</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Youtube----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>10</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p>INR 5,999</p></div>
        <div class="td bg-blue"><p>USD 100</p></div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft1">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft1">
            <div class="ft-content">
            <div class="ft-header"><span>Social Media Optimization - Economy package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="Social Media Optimization - Gold package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
    
    <div class="star-clmn">
        <div class="thead bg-purple star white star-banner"><p>Most Popular</p></div>
        <div class="thead bg-tealblue"><p>Silver</p></div>
        <div class="td bg-blue"><p></p></div>                                       <!-----blank col facebook----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>8</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>8</p></div>
        <div class="td"><p>2</p></div>
        <div class="td"><p>3</p></div>
        <div class="td"><p>3</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>One Time</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>Additional</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Twitter----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>8</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>Additional</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Linkedin----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>8</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>2</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>5</p></div>
        <div class="td"><p>2</p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Pinterest----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>5</p></div>
        <div class="td"><p>8</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Youtube----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>20</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p>INR 9,999</p></div>
        <div class="td bg-blue"><p>USD 150</p></div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft2">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft2">
            <div class="ft-content">
            <div class="ft-header"><span>Social Media Optimization - Silver package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="Social Media Optimization - Silver package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
    
    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead"><p>Gold</p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col facebook----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>16</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>16</p></div>
        <div class="td"><p>2</p></div>
        <div class="td"><p>5</p></div>
        <div class="td"><p>5</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>One Time</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>Additional</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Twitter----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>16</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>Additional</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Linkedin----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>16</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>3</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>10</p></div>
        <div class="td"><p>3</p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Pinterest----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>10</p></div>
        <div class="td"><p>16</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p></p></div>                               <!-----blank col Youtube----->
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p>50</p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td"><p><i class="icon yes"></i></p></div>
        <div class="td bg-blue"><p>INR 14,999</p></div>
        <div class="td bg-blue"><p>USD 200</p></div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft3">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft3">
            <div class="ft-content">
            <div class="ft-header"><span>Social Media Optimization - Gold package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="Social Media Optimization - Gold package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
    
    </div>
    <div class="ft_gst">
    <p>*GST Applicable On All Plans</p>
    </div>