<div class="ft_pakcge-div">
    <div class="ft-1st-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead border-0 bg-transparent"></div>
        <div class="th bg-blue">
            <p>ANALYSIS & DELVERABLES</p>
        </div>
        <div class="th has-icon">
            <p>Web Analysis</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Competition Ananlysis</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Content Duplicacy Check</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Keywords Finalize</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Search Engine Optimization Strategy</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Initial Ranking report</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th bg-blue">
            <p>ON PAGE OPTIMIZATION</p>
        </div>
        <div class="th has-icon">
            <p>Website Structure Optimization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Canonicalization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Content Optimization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Image Optimization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>HTML Code Optimization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>HTML Site Map Creation</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Google XML Site Map Creation & Regular Updation</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Google Analytics Set up</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Robots .txt optimization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>RSS Feed generation</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Page speed Optimization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Google Mobile Optimization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th bg-blue">
            <p>OFF PAGE ACTIVITEIS (MONTHLY BASED)</p>
        </div>
        <div class="th has-icon">
            <p>Manual Search Engine Submission</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Manual Relevant directory Submission</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Local/ Niche Directory submission</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Link Exchange (One Way + Reciprocal)</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th bg-blue">
            <p>SOCIAL MEDIA OPTIMIZATION</p>
        </div>
        <div class="th has-icon">
            <p>Social Bookmarking and Community Advertising</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Social Networking Profile</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Article Posting</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Article Submission (Per Article)</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>(Per Article).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Press Release Creation</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Press Release Distribution</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>(Per Press Release).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Blog Creation, Updation & Promotion</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Blog Posting</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Forum Posting</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Classified ad Creation & Posting</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>RSS Feeds Submission</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Video Promotion</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>(To be provided by client).
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th bg-blue">
            <p>REPORT STATUS</p>
        </div>
        <div class="th has-icon">
            <p>Search Engine Ranking Reports</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Monthly Work Status report (Detailed)</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Client Support</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Traffic Status report</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon bg-blue">
            <p>Price (INR)</p>
            <span class="icon-anchor">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon bg-blue">
            <p>Price (USD)</p>
            <span class="icon-anchor">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
    </div>


    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead">
            <p>Economy</p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>10</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>10</p>
        </div>
        <div class="td">
            <p>7</p>
        </div>
        <div class="td">
            <p>5</p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p>30</p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td">
            <p>1</p>
        </div>
        <div class="td">
            <p>40</p>
        </div>
        <div class="td">
            <p>0</p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td">
            <p>1</p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td">
            <p>Email</p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td bg-blue">
            <p>INR 7000</p>
        </div>
        <div class="td bg-blue">
            <p>USD 100</p>
        </div>
        <div class="button-clmn">
            <button class="ft-open" data-modal="ft1">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft1">
            <div class="ft-content">
            <div class="ft-header"><span>Local SEO - Economy package</span>
                <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
                <div class="adForm">
                    <form action="messages/order-received" method="post">    <!-- new Insert ---->
                        <?php include('parts/forms/order-form.php'); ?>
                        <input type="hidden" name="uPackage" value="Local SEO- Economy Package">
                     </form>
                  </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
    </div>
        </div>
    </div>


    <div class="star-clmn">
        <div class="thead bg-purple star white star-banner">
            <p>Most Popular</p>
        </div>
        <div class="thead bg-tealblue">
            <p>Silver</p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>15</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>10</p>
        </div>
        <div class="td">
            <p>10</p>
        </div>
        <div class="td">
            <p>7</p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p>40</p>
        </div>
        <div class="td">
            <p>5</p>
        </div>
        <div class="td">
            <p>2</p>
        </div>
        <div class="td">
            <p>50</p>
        </div>
        <div class="td">
            <p>0</p>
        </div>
        <div class="td">
            <p>30</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>2</p>
        </div>
        <div class="td">
            <p>5</p>
        </div>
        <div class="td">
            <p>2</p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td">
            <p>Email</p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td bg-blue">
            <p>INR 9000</p>
        </div>
        <div class="td bg-blue">
            <p>USD 125</p>
        </div>
        <div class="button-clmn">
            <button class="ft-open" data-modal="ft2">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft2">
            <div class="ft-content">
            <div class="ft-header"><span>Local SEO - Silver package</span>
                <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
                <div class="adForm">
                    <form action="messages/order-received" method="post">    <!-- new Insert ---->
                        <?php include('parts/forms/order-form.php'); ?>
                        <input type="hidden" name="uPackage" value="Local SEO - Silver package">
                     </form>
                </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
    </div>
        </div>
    </div>

    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead">
            <p>Gold</p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>20</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>15</p>
        </div>
        <div class="td">
            <p>15</p>
        </div>
        <div class="td">
            <p>10</p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p>50</p>
        </div>
        <div class="td">
            <p>10</p>
        </div>
        <div class="td">
            <p>3</p>
        </div>
        <div class="td">
            <p>60</p>
        </div>
        <div class="td">
            <p>1</p>
        </div>
        <div class="td">
            <p>40</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>3</p>
        </div>
        <div class="td">
            <p>10</p>
        </div>
        <div class="td">
            <p>3</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>Email/Chat</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p>INR 12,000</p>
        </div>
        <div class="td bg-blue">
            <p>USD 150</p>
        </div>
        <div class="button-clmn">
            <button class="ft-open" data-modal="ft3">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft3">
            <div class="ft-content">
            <div class="ft-header"><span>Local SEO - Gold package</span>
                <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
                <div class="adForm">
                    <form action="messages/order-received" method="post">    <!-- new Insert ---->
                        <?php include('parts/forms/order-form.php'); ?>
                        <input type="hidden" name="uPackage" value="Local SEO - Gold package">
                     </form>
                  </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
    </div>
        </div>
    </div>

    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead">
            <p>Platinum</p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>30</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>20</p>
        </div>
        <div class="td">
            <p>20</p>
        </div>
        <div class="td">
            <p>15</p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p>60</p>
        </div>
        <div class="td">
            <p>15</p>
        </div>
        <div class="td">
            <p>4</p>
        </div>
        <div class="td">
            <p>70</p>
        </div>
        <div class="td">
            <p>2</p>
        </div>
        <div class="td">
            <p>50</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>4</p>
        </div>
        <div class="td">
            <p>20</p>
        </div>
        <div class="td">
            <p>4</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>Email/Chat</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p>INR 20,000</p>
        </div>
        <div class="td bg-blue">
            <p>USD 300</p>
        </div>
        <div class="button-clmn">
            <button class="ft-open" data-modal="ft4">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft4">
            <div class="ft-content">
            <div class="ft-header"><span>Local SEO - Platinum package</span>
                <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
                <div class="adForm">
                    <form action="messages/order-received" method="post">    <!-- new Insert ---->
                        <?php include('parts/forms/order-form.php'); ?>
                        <input type="hidden" name="uPackage" value="Local SEO - Platinum package">
                     </form>
                  </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
    </div>
        </div>
    </div>

</div>

<div class="ft_gst">
    <p>*GST Applicable On All Plans</p>
    </div>