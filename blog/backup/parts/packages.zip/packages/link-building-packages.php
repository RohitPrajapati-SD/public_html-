<div class="ft_pakcge-div">
    <div class="ft-1st-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead border-0 bg-transparent"></div>
        <div class="th has-icon">
                <p>Price</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
            <div class="th has-icon">
                <p>Monthly guaranteed backlinks</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th bg-blue">
                <p>DELVERABLES</p>
        </div>
        <div class="th has-icon">
                <p>Guest Post</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Guest Post Social Bookmarking</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Unique Article Writing</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Articles Submission</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Article Social Bookmarking</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>PDF Submission*</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>PDF Bookmarking</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Unique PR Writing</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Press Releases Submission</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>PR Social Bookmarking</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Website Social Bookmarking Links</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Web 2.0 Profile Creation</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Profile Social Bookmarking Links</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Web 2.0 Blog Posts</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
        <div class="th has-icon">
                <p>Web 2.0 Blog Bookmarking Links</p>
                <span class="icon-anchor">
                   <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
                </span>
        </div>
    </div>
    
    
    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead"><p>Basic</p></div>
        <div class="td"><p><span class="ft_price"><sup>$</sup>150<span class="small">/month</span></span></p></div>
        <div class="td"><p><span class="ft_price">90</p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>20</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>20</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>30</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>20</p></div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft1">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft1">
            <div class="ft-content">
            <div class="ft-header"><span>Link Building - Basic package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="Link Building - Basic package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
    
    
    <div class="star-clmn">
        <div class="thead bg-purple star white star-banner"><p>Most Popular</p></div>
        <div class="thead bg-tealblue"><p>Standard</p></div>
        <div class="td"><p><span class="ft_price"><sup>$</sup>300<span class="small">/month</span></span></p></div>
        <div class="td"><p><span class="ft_price">200</p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>30</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>40</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>40</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>60</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>40</p></div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft2">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft2">
            <div class="ft-content">
            <div class="ft-header"><span>Link Building - Standard package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="Link Building - Standard package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
    
    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead"><p>Professional</p></div>
        <div class="td"><p><span class="ft_price"><sup>$</sup>600<span class="small">/month</span></span></p></div>
        <div class="td"><p><span class="ft_price">400</p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p>3</p></div>
        <div class="td"><p>80</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>60</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>60</p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p><i class="icon no"></i></p></div>
        <div class="td"><p>100</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>20</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>80</p></div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft3">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft3">
            <div class="ft-content">
            <div class="ft-header"><span>Link Building - Professional package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="Link Building - Professional package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
    
    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead"><p>Enterprise</p></div>
        <div class="td"><p><span class="ft_price"><sup>$</sup>1000<span class="small">/month</span></span></p></div>
        <div class="td"><p><span class="ft_price">800</p></div>
        <div class="td bg-blue"><p></p></div>
        <div class="td"><p>8</p></div>
        <div class="td"><p>200</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>100</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>100</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>20</p></div>
        <div class="td"><p>150</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>40</p></div>
        <div class="td"><p>1</p></div>
        <div class="td"><p>100</p></div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft4">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft4">
            <div class="ft-content">
            <div class="ft-header"><span>Link Building - Enterprise package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="Link Building - Enterprise package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
    
    </div>

    <div class="ft_gst">
    <p>*GST Applicable On All Plans</p>
    </div>