<div class="ft_pakcge-div">
    <div class="ft-1st-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead border-0 bg-transparent"></div>
        <div class="th has-icon">
            <p>Monthly Budget (INR)</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Monthly Budget (USD)</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Account Setup</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Competitor Analysis</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Bid Management</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Keyword Research and Selection</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Creative Ads Development</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Ad Scheduling Setup</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Ad Group Creation</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Text Ad Creation</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Image Ad Creation</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Google Ad Extensions</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Conversion Optimization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Placement Sites Targeting</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Site Exclusion & Optimization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Google Analytics Set up</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Demographic Bidding</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Setup Time Frame</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Landing Page Optimization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Landing Page Creation</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Quality Score Optimization</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>ROI Calculation</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th bg-blue">
            <p>REPORT STATUS</p>
        </div>
        <div class="th has-icon">
            <p>Weekly Reports</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon">
            <p>Monthly Reports</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon bg-blue">
            <p>One Time Setup Fees</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon bg-blue">
            <p>Setup Fees (USD)</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
        <div class="th has-icon bg-blue">
            <p>Management Fees* (Minimum Billing USD100)</p>
            <span class=" ">
                <div class="icon-cont">
                    <p>Contact us for volume discounts or see our Agency and Partner plans.
                        <a href="#" class="auto-track" target="_blanks">Learn More</a>
                    </p>
                </div>
            </span>
        </div>
    </div>


    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead">
            <p>Economy</p>
        </div>
        <div class="td">
            <p>Up to 50k</p>
        </div>
        <div class="td">
            <p>Up to 1000</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>Up to 20</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>7 Days</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon no"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p>INR 15,000</p>
        </div>
        <div class="td bg-blue">
            <p>USD 200</p>
        </div>
        <div class="td bg-blue">
            <p>18%</p>
        </div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft1">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft1">
            <div class="ft-content">
            <div class="ft-header"><span>PPC - Economy package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="PPC - Economy package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>


    <div class="star-clmn">
        <div class="thead bg-purple star white star-banner">
            <p>Most Popular</p>
        </div>
        <div class="thead bg-tealblue">
            <p>Silver</p>
        </div>
        <div class="td">
            <p>50k-2Lac</p>
        </div>
        <div class="td">
            <p>3000</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>Up to 50</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>7 Days</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p>INR 15,000</p>
        </div>
        <div class="td bg-blue">
            <p>USD 200</p>
        </div>
        <div class="td bg-blue">
            <p>15%</p>
        </div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft2">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft2">
            <div class="ft-content">
            <div class="ft-header"><span>PPC - Silver package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="PPC - Silver package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>

    <div class="normal-clmn">
        <div class="thead border-0 bg-transparent"></div>
        <div class="thead">
            <p>Gold</p>
        </div>
        <div class="td">
            <p>2Lac+</p>
        </div>
        <div class="td">
            <p>3000+</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>Unlimited</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p>7 Days</p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td">
            <p><i class="icon yes"></i></p>
        </div>
        <div class="td bg-blue">
            <p>INR 15,000</p>
        </div>
        <div class="td bg-blue">
            <p>USD 200</p>
        </div>
        <div class="td bg-blue">
            <p>12%</p>
        </div>
        <div class="button-clmn">
            <!-- pop-up-button -->
            <button class="ft-open" data-modal="ft3">Order Now</button>
            <!--Modals-->
            <div class="ft" id="ft3">
            <div class="ft-content">
            <div class="ft-header"><span>PPC - Gold package</span>
            <button class="icon ft-close">&times;</button>
            </div>
            <div class="ft-body">
            <div class="adForm">
                <form action="messages/order-received" method="post">    <!-- new Insert ---->
                <?php include('parts/forms/order-form.php'); ?>
               <input type="hidden" name="uPackage" value="PPC - Gold package">
                </form>
            </div>
            </div>
            <div class="ft-footer"><button class="link ft-close">close</button></div>
            </div>
            </div><!--Modal End-->
        </div>
    </div>
</div>

    <div class="ft_gst">
    <p>*GST Applicable On All Plans</p>
    </div>